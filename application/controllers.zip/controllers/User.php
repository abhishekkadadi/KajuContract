<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {

	public function userSignUp(){
		$userName = $_POST['userName'];
		$userEmail = $_POST['userEmail'];
		$this->load->model('User_model');
		$data=$this->User_model->userSignUp();
		 if($data === 'emailPresent')
          {
             $userdata['status']=email_present();
             $this->output->set_content_type('application/json')->set_output(json_encode($userdata));  
          }else if($data){
                $userId=urlencode(base64_encode($data));
                $result['sitelink']= site_url("Verifymail/Verifyuser/$userId");
                $result['email']=$userEmail;
                $result['name']=$userName;
                $template='userverify';          
                $send_mail=sendMail($result,$template); 
                $userdata['status']=success_register();
                $userdata['data']=array('userId'=>$data);
             $this->output->set_content_type('application/json')->set_output(json_encode($userdata));
          }else{
               $final_data['status']=failed();
               $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
               }

	}//AduserSignUpdUser


	 Public function UserLogin(){
      $isSupplier=$_POST['isSupplier'];
	   	$this->load->model('User_model');
	   	$data=$this->User_model->Login();
	   	if($data==='noverify'){
	   			$userdata['status']=verify_needed();
	   			$this->output->set_content_type('application/json')->set_output(json_encode($userdata));
	   	}else if($data){
	   			  
	              $userdata['status']=success_login();
                if($isSupplier==0){
                foreach ($data as $key) {
                  $userId=$key['userId'];
                  $userName=$key['userName'];
                  $userEmail=$key['userEmail'];
                  $userContact=$key['userContact'];
                  $token=$key['token'];
                  $chatId=$key['chatId'];
                  $timeStamp=$key['timeStamp'];
                  $packageId=$key['packageId'];
                  $isVerified=$key['isVerified'];
                  $userType=$key['userType'];

                  $userdata['data']=array('userId'=>$userId,'userName'=>$userName,'userEmail'=>$userEmail,'userContact'=>$userContact,'token'=>$token,'chatId'=>$chatId,'timeStamp'=>$timeStamp,'packageId'=>$packageId,'isVerified'=>$isVerified,'userType'=>$userType);
                }
              }else{
                 foreach ($data as $key) {
                  $userId=$key['supplierId'];
                  $userName=$key['supplierName'];
                  $userEmail=$key['supplierEmail'];
                  $userContact=$key['supplierContact'];
                  $userAddress=$key['supplierAddress'];
                  $chatId=$key['supplierChatId'];
                  $isVerified=$key['isVerified'];
                  }
                  $userdata['data']=array('userId'=>$userId,'userName'=>$userName,'userEmail'=>$userEmail,'userContact'=>$userContact,'userAddress'=>$userAddress,'chatId'=>$chatId,'isVerified'=>$isVerified,'isSupplier'=>$isSupplier);

              }
	              
            //print_r($data);  
		 		  $this->output->set_content_type('application/json')->set_output(json_encode($userdata));
	   	}else{

		 		 $userdata['status']=failed_login();
		 		 $this->output->set_content_type('application/json')->set_output(json_encode($userdata));
	   	}
   }//UserLogin


   public function AddChatId(){
    $this->load->model('User_model');
    $data=$this->User_model->AddChatId();
    if($data){
               $final_data['status']=success_update();
               $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }else{
              $final_data['status']=failed();
              $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }
   }//AddChatId

   public function editUser(){
    $this->load->model('User_model');
    $data=$this->User_model->editUser();
    if($data){
               $final_data['status']=success_update();
               $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }else{
              $final_data['status']=failed();
              $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }
   }//editUser

   
   public function displayContractors(){
    $this->load->model('User_model');
    $data=$this->User_model->fetchViewedSupplier();
    $data2=$this->User_model->checkSuppliers();   
    if(!empty($data2) || !empty($data)){
             $final_data['status']=success_fetch();
             unset($data2[0]['supplierPassword']);
             unset($data[0]['supplierPassword']);
             $final_data['notviewed']=$data2;
             $final_data['viewed']=$data;
             $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }else{
              $final_data['status']=no_data();
              $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }
    
   }//displayContractors

  public function viewedSuppliers(){
    $this->load->model('User_model');
    $data=$this->User_model->viewedSuppliers();
    if($data){
               $final_data['status']=success_insert();
               $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }else{
              $final_data['status']=failed();
              $this->output->set_content_type('application/json')->set_output(json_encode($final_data));
    }
   }//viewedSuppliers

   


}//User
?>