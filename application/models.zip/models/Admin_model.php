<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_model extends CI_Model {
	
	            public function Login()
                { 
                	$userName=$_POST['userName'];
                	$userPassword=$_POST['userPassword'];
                	$token=$_POST['token'];
                	$query=$this->db->get_where('adminlogin',array('userName'=>$userName,'userPassword'=>$userPassword));
                    if($query->num_rows()==1){
                    	foreach ($query->result_array() as $key) {
                    		  $adminId=$key['loginId'];
                    	}//foreach
                    	$this->db->where('loginId',$adminId);
                    	$data=array('token'=>$token);
                    	$this->db->update('adminlogin',$data);
                        return $query->result_array();
                    }else{
                    	return false;
                    }
                }//Login
                
                
               public function AddSupplier()
                { 
                    $supplierName = $_POST['supplierName'];
                    $supplierEmail = $_POST['supplierEmail'];
                    $supplierContact = $_POST['supplierContact'];
                    $supplierPassword = $_POST['supplierContact'];
                    $supplierAddress=$_POST['supplierAddress'];
                   
                    $checkemail=$this->checkAlreadyEmail($supplierEmail);

                if($checkemail==1){
                            return 'emailPresent';
                        }else{
                            $data=array(
                                        'userName'=> $supplierName,
                                        'userEmail'=> $supplierEmail,
                                        'userContact'=> $supplierContact,
                                        'userPassword'=> $supplierContact,
                                        'userAddress'=> $supplierAddress,
                                        'userType'=> '2',
                                        
                                       );
                                    
                                    $this->db->insert('user', $data);
                                    if($this->db->affected_rows() == 1){
                                        return $this->db->insert_id();
                                    }else{
                                        return false;
                                    }   
                        }
                }//AddSupplier


                public function checkAlreadyEmail($email){
                    $this->db->where('userEmail',$email);
                    $query = $this->db->get('user');
                    if ($query->num_rows() > 0){
                        return true;
                    }
                    else{
                        return false;
                    }
                }//checkAlreadyEmail
                
                
               public function AddChatId(){
                    $supplierId=$_POST['supplierId'];
                    $supplierChatId=$_POST['supplierChatId'];
                    $this->db->where('userId',$supplierId);
                    $data=array('chatId'=>$supplierChatId);
                    $this->db->update('user',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;   
                }//AddChatId
                

                 public function AddPackage(){
                    $packageName=$_POST['packageName'];
                    $packageLimit=$_POST['packageLimit'];
                    $data=array('packageName'=>$packageName,'packageLimit'=>$packageLimit);
                    $this->db->insert('package',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;   
                }//AddPackage
                
                
                 public function displayPackages(){
                    $query=$this->db->get('package');
                    return $query->result_array();   
                }//displayPackages
                
                public function updatePackage(){
                    $packageId=$_POST['packageId'];
                    $packageName=$_POST['packageName'];
                    $packageLimit=$_POST['packageLimit'];
                    $data=array('packageName'=>$packageName,'packageLimit'=>$packageLimit);
                    $this->db->where('packageId',$packageId);
                    $this->db->update('package',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;  
                }//updatePackage
                
                public function supplierList(){
                    $query=$this->db->get_where('user',array('userType'=>'2'));
                    return $query->result_array();
                }//supplierList
                
                 public function userList(){
                    $this->db->select('u.*,p.packageName');
                    $this->db->from('user as u');
                    $this->db->join('package as p','p.packageId=u.packageId','left');
                    return $this->db->get()->result_array();
                }//userList

                
                public function attachPackage(){
                    $userId=$_POST['userId'];
                    $packageId=$_POST['packageId'];
                    $data=array('packageId'=>$packageId);
                    $this->db->where('userId',$userId);
                    $this->db->update('user',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;
                }//attachPackage
                
                public function setSupplier(){
                    $packageId=$_POST['packageId'];
                    $supplierId=$_POST['supplierId'];
                    $packageIdarray=explode(",", $supplierId);
                    $this->db->where('packageId',$packageId);
                    $this->db->delete('displaysetsuppliers');
                    foreach ($packageIdarray as $key => $value) {
                        $data=array('packageId'=>$packageId,
                                    'supplierId'=>$value);
                        $finalArray[]=$data;
                    }
                    $query=$this->db->insert_batch('displaysetsuppliers',$finalArray);
                     return ($this->db->affected_rows() >= 1) ? true : false;
                }//setSupplier
                
}
?>