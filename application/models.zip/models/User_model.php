<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends CI_Model {

 public function userSignUp(){
 	 			$userName = $_POST['userName'];
		        $userEmail = $_POST['userEmail'];
		        $userContact = $_POST['userContact'];
		        $userPassword = $_POST['userPassword'];
                $userType=$_POST['userType'];
		         
		        $checkemail=$this->checkAlreadyEmail($userEmail);

		        if($checkemail==1){
			        		return 'emailPresent';
			        	}else{
			        		$data=array(
							    		'userName'=> $userName,
							    		'userEmail'=> $userEmail,
							    		'userContact'=> $userContact,
							    		'userPassword'=> $userPassword,
                                        'userType'=>$userType
							    	
	                                   );
				        			
								    $this->db->insert('user', $data);
									if($this->db->affected_rows() == 1){
										return $this->db->insert_id();
									}else{
										return false;
									}	
			        	}

 }//userSignUp
 
 public function checkAlreadyEmail($email){
             		$this->db->where('userEmail',$email);
				    $query = $this->db->get('user');
				    if ($query->num_rows() > 0){
				        return true;
				    }
				    else{
				        return false;
				    }
 }//checkAlreadyEmail

 public function Login()
                { 
                	$userEmail=$_POST['userEmail'];
                	$userPassword=$_POST['userPassword'];
                	$token=$_POST['token'];
                	$query=$this->db->get_where('user',array('userEmail'=>$userEmail,'userPassword'=>$userPassword));
                    if($query->num_rows()==1){
                    	foreach ($query->result_array() as $key) {
                    		  $userId=$key['userId'];
                    		  $isVerified=$key['isVerified'];
                    	}//foreach
                    	if($isVerified==1){
                    	$this->db->where('userId',$userId);
                    	$data=array('token'=>$token);
                    	$this->db->update('user',$data);
                        return $query->result_array();
                    }else{
                    	return 'noverify';
                    }
                    }else{
                    	return false;
                    }
                  
                }//Login
    
    public function AddChatId(){
                    $userId=$_POST['userId'];
                    $chatId=$_POST['chatId'];
                    $this->db->where('userId',$userId);
                    $data=array('chatId'=>$chatId);
                    $this->db->update('user',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;   
                }//AddChatId

    public function editUser(){
                    
                    $userId=$_POST['userId'];
                    
                        $data=array(
                                'userName'=>$_POST['userName'],
                                'userContact'=>$_POST['userContact'],

                                );
                        if(isset($_POST['userAddress'])){
                            $data['userAddress']=$_POST['userAddress'];
                        }
                        $this->db->where('userId',$userId);
                        $this->db->update('user',$data);
                   
                    return ($this->db->affected_rows() != 1) ? false : true;   
                }//editUser


     public function displayContractors(){
                    $userId=$_POST['userId'];
                    $packageId=$this->getPackageId($userId);
                    $this->db->select('s.*');
                    $this->db->from('supplier as s');
                    $this->db->join('displaysetsuppliers as ds','ds.supplierId=s.supplierId');
                    $this->db->where('ds.packageId',$packageId);
                    return $this->db->get()->result_array();
                }//displayContractors
                

 public function viewedSuppliers(){
                    $userId=$_POST['userId'];
                    $supplierId=$_POST['supplierId'];
                    $data=array('userId'=>$userId,'supplierId'=>$supplierId);
                    $this->db->insert('viewedsuppliers',$data);
                    return ($this->db->affected_rows() != 1) ? false : true;   
                }//viewedSuppliers

 public function checkSuppliers(){
                    $userId=$_POST['userId'];
                    $packageId=$this->getPackageId($userId);
                    $data=$this->getViewedids($userId);
                    $this->db->select('s.*');
                    $this->db->from('supplier as s');
                    $this->db->join('displaysetsuppliers as ds','ds.supplierId=s.supplierId');
                    $this->db->where('ds.packageId',$packageId);
                    if(!empty($data)){
                    $this->db->where_not_in('ds.supplierId', $data);
                    }
                    return $this->db->get()->result_array();
                }//checkSuppliers

 public function fetchViewedSupplier(){
                    $userId=$_POST['userId'];
                    $this->db->select('s.*');
                    $this->db->from('supplier as s');
                    $this->db->join('viewedsuppliers as vs','vs.supplierId=s.supplierId');
                    $this->db->where('vs.userId',$userId);
                    return $this->db->get()->result_array();
                }//fetchViewedSupplier

public function getViewedids($userId){
       $query=$this->db->get_where('viewedsuppliers',array('userId'=>$userId));
       $data1=array();
        foreach($query->result_array() as $row)
       {
        $data1[] = $row['supplierId']; // add each user id to the array
       }
    return $data1;
}//getViewedids

public function getPackageId($userId){
       $query=$this->db->get_where('user',array('userId'=>$userId));
       foreach ($query->result_array() as $key) {
               $packageId=$key['packageId'];
       }
       return $packageId;
}//getPackageId

}//User_model

?>